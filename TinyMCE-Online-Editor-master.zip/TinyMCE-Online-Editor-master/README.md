# TinyMCE-Online-Editor
使用TinyMCE來實作的線上編輯器

* Online Demo: https://pulipulichen.github.io/TinyMCE-Online-Editor/
* Link Builder: https://pulipulichen.github.io/TinyMCE-Online-Editor/link-builder.html
* GitHub Repositroy: https://github.com/pulipulichen/TinyMCE-Online-Editor


# Load Parameters from URL:
* https://pulipulichen.github.io/TinyMCE-Online-Editor/?filename=Default%20Filename
* https://pulipulichen.github.io/TinyMCE-Online-Editor/?content=Default%20Content
* https://pulipulichen.github.io/TinyMCE-Online-Editor/?filename=Default%20Filename&content=Default%20Content
